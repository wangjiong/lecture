package com.badlogic.androidgames.gobang;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.os.Handler;
import android.os.Message;

import com.badlogic.androidgames.framework.Screen;
import com.badlogic.androidgames.framework.impl.GLGame;

public class GobangGame extends GLGame {
	static final int MSG_REPLAY = 0;
	static final int MSG_OPTION = 1;
	static final int MSG_EXIT = 2;
	static final int MSG_BLACK_WIN = 3;
	static final int MSG_WHITE_WIN = 4;
	static final int MSG_DRAW = 5;
	int item = 0;
	Handler handler = new Handler() {
		public void handleMessage(Message msg) {
			if (msg.what == MSG_REPLAY) {
				AlertDialog.Builder builder = new AlertDialog.Builder(
						(Context) GobangGame.this);
				builder.setMessage("ȷ��������");
				builder.setTitle("��ʾ");
				builder.setPositiveButton("ȷ��", new OnClickListener() {
					public void onClick(DialogInterface dialog, int which) {
						GameScreen.initAi();
					}
				});
				builder.setNegativeButton("ȡ��", null);
				builder.create().show();
			}
			if (msg.what == MSG_OPTION) {
				item = 0;
				AlertDialog.Builder builder = new AlertDialog.Builder(
						(Context) GobangGame.this);
				String[] items = null;
				if (Settings.soundEnabled) {
					items = new String[] { "����", "����-��", "����" };
				} else {
					items = new String[] { "����", "����-��", "����" };
				}
				builder.setTitle("ѡ��");
				builder.setSingleChoiceItems(items, 0, new OnClickListener() {
					public void onClick(DialogInterface dialog, int which) {
						item = which;
					}
				});
				builder.setPositiveButton("ȷ��", new OnClickListener() {
					public void onClick(DialogInterface dialog, int which) {
						switch (item) {
						case 0:// ����
							GameScreen.chessFlag = true;
							GameScreen.backAi();
							break;
						case 1:// ����
							if (Settings.soundEnabled) {
								Assets.music.pause();
								Settings.soundEnabled = false;
							} else {
								Assets.music.play();
								Settings.soundEnabled = true;
							}
							break;
						case 2:// ����
							handler.sendEmptyMessage(GobangGame.MSG_WHITE_WIN);
							break;
						}
					}
				});
				builder.setNegativeButton("ȡ��", null);
				builder.create().show();
			}
			if (msg.what == MSG_EXIT) {
				AlertDialog.Builder builder = new AlertDialog.Builder(
						(Context) GobangGame.this);
				builder.setMessage("ȷ���˳���");
				builder.setTitle("��ʾ");
				builder.setPositiveButton("ȷ��", new OnClickListener() {
					public void onClick(DialogInterface dialog, int which) {
						Chess.clear();
						GameScreen.initAi();
						((Activity) GobangGame.this).finish();
					}
				});
				builder.setNegativeButton("ȡ��", null);
				builder.create().show();
			}
			if (msg.what == MSG_BLACK_WIN) {
				AlertDialog.Builder builder = new AlertDialog.Builder(
						(Context) GobangGame.this);
				builder.setMessage("�����ʤ��");
				builder.setTitle("��ʾ");
				builder.setPositiveButton("ȷ��", new OnClickListener() {
					public void onClick(DialogInterface dialog, int which) {
						Chess.clear();
						GameScreen.initAi();
					}
				});
				builder.setCancelable(false);
				builder.create().show();
			}
			if (msg.what == MSG_WHITE_WIN) {
				AlertDialog.Builder builder = new AlertDialog.Builder(
						(Context) GobangGame.this);
				builder.setMessage("�����ʤ��");
				builder.setTitle("��ʾ");
				builder.setPositiveButton("ȷ��", new OnClickListener() {
					public void onClick(DialogInterface dialog, int which) {
						Chess.clear();
						GameScreen.initAi();
					}
				});
				builder.setNegativeButton("ȡ��", null);
				builder.setCancelable(false);
				builder.create().show();
			}
			if (msg.what == MSG_DRAW) {
				AlertDialog.Builder builder = new AlertDialog.Builder(
						(Context) GobangGame.this);
				builder.setMessage("ƽ�֣�");
				builder.setTitle("��ʾ");
				builder.setPositiveButton("ȷ��", new OnClickListener() {
					public void onClick(DialogInterface dialog, int which) {
						Chess.clear();
						GameScreen.initAi();
					}
				});
				builder.setNegativeButton("ȡ��", null);
				builder.setCancelable(false);
				builder.create().show();
			}
		}
	};
	boolean firstTimeCreate = true;

	public Screen getStartScreen() {
		return new GameScreen(this);
	}

	@Override
	public void onSurfaceCreated(GL10 gl, EGLConfig config) {
		super.onSurfaceCreated(gl, config);
		if (firstTimeCreate) {
			Assets.load(this);
			firstTimeCreate = false;
		} else {
			Assets.reload();
		}
	}

	protected void onPause() {
		super.onPause();
		Assets.music.pause();
	}
}
