package com.badlogic.androidgames.gobang;

public class Constant {
	public static final int WIDTH=320;
	public static final int HEIGHT=480;
}
