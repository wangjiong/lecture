package com.badlogic.androidgames.gobang;


public class Board {
	public static final float PIPE_WIDTH = 320f;
	public static final float PIPE_HEIGHT = 480f;
	public static final int SIZE_WIDTH = 9;
	public static final int SIZE_HEIGHT = 9;
}
