package com.badlogic.androidgames.gobang;

public class Chess {
	public static final float PIPE_WIDTH = 36f;
	public static final float PIPE_HEIGHT = 36f;

	public static final int NULL = 0;
	public static final int BLACK = 1;
	public static final int WHITE = 2;
	public static final int[][] chesses = new int[9][9];

	public static final void clear() {
		for (int col = 0; col < 9; col++)
			for (int row = 0; row < 9; row++)
				Chess.chesses[col][row] = Chess.NULL;
	}

	public static boolean check(final int col, final int row, final int type) {
		int colTemp = col, rowTemp = row;
		int count = 1;
		// ����
		while (colTemp > 0) {
			colTemp--;
			if (Chess.chesses[colTemp][row] == type) {
				count++;
				if (count == 5) {
					return true;
				}
			} else {
				break;
			}
		}
		colTemp = col;
		while (colTemp < 8) {
			colTemp++;
			if (Chess.chesses[colTemp][row] == type) {
				count++;
				if (count == 5) {
					return true;
				}
			} else {
				break;
			}
		}
		// ����
		count = 1;
		colTemp = col;
		while (rowTemp > 0) {
			rowTemp--;
			if (Chess.chesses[col][rowTemp] == type) {
				count++;
				if (count == 5) {
					return true;
				}
			} else {
				break;
			}
		}
		rowTemp = row;
		while (rowTemp < 8) {
			rowTemp++;
			if (Chess.chesses[col][rowTemp] == type) {
				count++;
				if (count == 5) {
					return true;
				}
			} else {
				break;
			}
		}
		// ����������\
		count = 1;
		rowTemp = row;
		while (rowTemp > 0 && colTemp < 8) {
			rowTemp--;
			colTemp++;
			if (Chess.chesses[colTemp][rowTemp] == type) {
				count++;
				if (count == 5) {
					return true;
				}
			} else {
				break;
			}
		}
		rowTemp = row;
		colTemp = col;
		while (rowTemp < 8 && colTemp > 0) {
			rowTemp++;
			colTemp--;
			if (Chess.chesses[colTemp][rowTemp] == type) {
				count++;
				if (count == 5) {
					return true;
				}
			} else {
				break;
			}
		}
		// ����������/
		count = 1;
		rowTemp = row;
		colTemp = col;
		while (rowTemp < 8 && colTemp < 8) {
			rowTemp++;
			colTemp++;
			if (Chess.chesses[colTemp][rowTemp] == type) {
				count++;
				if (count == 5) {
					return true;
				}
			} else {
				break;
			}
		}
		rowTemp = row;
		colTemp = col;
		while (rowTemp > 0 && colTemp > 0) {
			rowTemp--;
			colTemp--;
			if (Chess.chesses[colTemp][rowTemp] == type) {
				count++;
				if (count == 5) {
					return true;
				}
			} else {
				break;
			}
		}
		return false;
	}
}
