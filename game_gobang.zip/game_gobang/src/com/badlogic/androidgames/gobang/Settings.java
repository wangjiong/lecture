package com.badlogic.androidgames.gobang;

public class Settings {
	public static boolean soundEnabled = true;
}
