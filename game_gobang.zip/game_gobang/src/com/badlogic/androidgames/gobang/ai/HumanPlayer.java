package com.badlogic.androidgames.gobang.ai;

import java.util.List;



public class HumanPlayer extends BasePlayer implements IPlayer{
	public void run(List<Point> enemyPoints,Point p) {
		getMyPoints().add(p);
		allFreePoints.remove(p);
	}
}
