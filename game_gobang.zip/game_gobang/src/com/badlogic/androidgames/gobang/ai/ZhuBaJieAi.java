package com.badlogic.androidgames.gobang.ai;

//���˽�
public class ZhuBaJieAi extends BaseComputerAi {


}
