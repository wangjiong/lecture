package com.badlogic.androidgames.gobang;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Iterator;
import java.util.Set;
import java.util.UUID;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothServerSocket;
import android.bluetooth.BluetoothSocket;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;

import com.badlogic.androidgames.gobang.ai.Point;

public class MainMenu extends Activity {
	Button bn_renji, bn_guanyu, bn_yinyue;
	Button bn_wangluo, bn_lanya;
	// ����
	String ipString = null;
	int item = 0;
	Thread threadServer = null;
	Thread threadClient = null;
	static PrintStream writerServer;
	static PrintWriter writerClient;
	static boolean isServer;
	static boolean isFinish = false;
	static Handler handler;
	UUID uuid = UUID.fromString("a60f35f0-b93a-11de-8a39-08002009c666");

	// ����
	BluetoothAdapter bluetooth;

	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		bluetooth = BluetoothAdapter.getDefaultAdapter();
		bn_renji = (Button) findViewById(R.id.renji);
		bn_renji.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				Intent intent = new Intent(MainMenu.this, GobangGame.class);
				startActivity(intent);
			}
		});
		bn_guanyu = (Button) findViewById(R.id.guanyu);
		bn_guanyu.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				Intent intent = new Intent(MainMenu.this, Guanyu.class);
				startActivity(intent);
			}
		});
		bn_yinyue = (Button) findViewById(R.id.yinyue);
		bn_yinyue.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				if (Settings.soundEnabled) {
					bn_yinyue.setText("����-��");
					Settings.soundEnabled = false;
				} else {
					bn_yinyue.setText("����-��");
					Settings.soundEnabled = true;
				}
			}
		});
		bn_wangluo = (Button) findViewById(R.id.wangluo);
		bn_wangluo.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				AlertDialog.Builder builder = new AlertDialog.Builder((Context) MainMenu.this);
				item = 0;
				builder.setTitle("ѡ��");
				builder.setSingleChoiceItems(new String[] { "����", "�ͻ�" }, 0, new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int which) {
						item = which;
					}
				});
				builder.setPositiveButton("ȷ��", new DialogInterface.OnClickListener() {
					@SuppressWarnings("deprecation")
					public void onClick(DialogInterface dialog, int which) {
						// ����
						if (item == 0) {
							isServer = true;
							final ProgressDialog progressDialog = new ProgressDialog(MainMenu.this);
							progressDialog.setTitle("�ȴ�����...");
							progressDialog.setCancelable(false);
							progressDialog.show();
							// ������
							threadServer = new Thread() {
								@SuppressWarnings("resource")
								public void run() {
									try {
										ServerSocket server = new ServerSocket(30000);
										Socket socket = server.accept();
										progressDialog.dismiss();
										Intent intent = new Intent(MainMenu.this, GobangGameWangluo.class);
										startActivity(intent);

										BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
										writerServer = new PrintStream(socket.getOutputStream(), true);
										while (true) {
											String line = reader.readLine();
											String[] temp = line.split(" ");
											if (temp.length == 1) {
												switch (Integer.parseInt(temp[0])) {
												case 1:// ����
													GameScreenWangluo.initNet();
													break;
												case 9:// �����Ѿ�����ȷ����ť
													isFinish = true;
													GameScreenWangluo.chessFlag = true;
													break;
												}
											} else {
												int col = Integer.parseInt(temp[0]);
												int row = Integer.parseInt(temp[1]);
												Chess.chesses[col][row] = Chess.WHITE;
												if (Chess.check(col, row, Chess.WHITE)) {// ����ʤ
													handler.sendEmptyMessage(GobangGameWangluo.MSG_WHITE_WIN);
												}
												GameScreenWangluo.player2.run(null, new Point(col, row));
												GameScreenWangluo.allFreePoints.add(new Point(col, row));
												GameScreenWangluo.chessFlag = true;
											}
										}
									} catch (IOException e) {
										e.printStackTrace();
									}
								}
							};
							threadServer.start();
							progressDialog.setButton("ȡ��", new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog, int which) {
									try {
										threadServer.interrupt();
									} catch (Exception e) {
										System.out.println("thread.interrupt();");
									}
								}
							});
						}
						// �� ��
						if (item == 1) {
							isServer = false;
							AlertDialog.Builder builder = new AlertDialog.Builder((Context) MainMenu.this);
							final EditText editText = new EditText((Context) MainMenu.this);
							editText.setHint("192.168.1.100");
							builder.setTitle("����������IP��ַ").setView(editText).setPositiveButton("ȷ��", new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog, int which) {
									String temp = editText.getText().toString().trim();
									ipString = temp;
									if (temp.equals("")) {
										ipString = "192.168.1.103";
									}
									final ProgressDialog progressDialog = new ProgressDialog(MainMenu.this);
									progressDialog.setTitle("��������...");
									progressDialog.setCancelable(false);
									progressDialog.show();
									// �ͻ���
									threadClient = new Thread() {
										@SuppressWarnings("resource")
										public void run() {
											try {
												Socket socket = new Socket(ipString, 30000);
												progressDialog.dismiss();
												Intent intent = new Intent(MainMenu.this, GobangGameWangluo.class);
												startActivity(intent);
												GameScreenWangluo.chessFlag = false;
												OutputStream out = socket.getOutputStream();
												BufferedReader reader1 = new BufferedReader(new InputStreamReader(socket.getInputStream()));
												writerClient = new PrintWriter(out, true);
												while (true) {
													String line = reader1.readLine();
													String[] temp = line.split(" ");
													if (temp.length == 1) {
														switch (Integer.parseInt(temp[0])) {
														case 1:// ����
															GameScreenWangluo.initNet();
															break;
														case 9:// �����Ѿ�����ȷ����ť
															isFinish = true;
															GameScreenWangluo.chessFlag = true;
															break;
														}
													} else {
														int col = Integer.parseInt(temp[0]);
														int row = Integer.parseInt(temp[1]);
														Chess.chesses[col][row] = Chess.WHITE;
														if (Chess.check(col, row, Chess.WHITE)) {// ����ʤ
															handler.sendEmptyMessage(GobangGameWangluo.MSG_WHITE_WIN);
														}
														GameScreenWangluo.player2.run(null, new Point(col, row));
														GameScreenWangluo.allFreePoints.add(new Point(col, row));
														GameScreenWangluo.chessFlag = true;
													}
												}
											} catch (IOException e) {
												e.printStackTrace();
											}
										}
									};
									threadClient.start();
								}

							});
							builder.setNegativeButton("ȡ��", null);
							builder.create().show();
						}
					}
				});
				builder.setNegativeButton("ȡ��", null);
				builder.create().show();
			}
		});
		bn_lanya = (Button) findViewById(R.id.lanya);
		bn_lanya.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				AlertDialog.Builder builder = new AlertDialog.Builder((Context) MainMenu.this);
				item = 0;
				builder.setTitle("ѡ��");
				builder.setSingleChoiceItems(new String[] { "����", "�ͻ�" }, 0, new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int which) {
						item = which;
					}
				});
				builder.setPositiveButton("ȷ��", new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int which) {
						// ����
						if (item == 0) {
							isServer = true;
							final ProgressDialog progressDialog = new ProgressDialog(MainMenu.this);
							progressDialog.setTitle("�ȴ�����...");
							progressDialog.setCancelable(false);
							progressDialog.show();
							// ������
							threadServer = new Thread() {
								public void run() {
									try {
										String name = "bluetoothserver";
										BluetoothServerSocket btserver = bluetooth.listenUsingRfcommWithServiceRecord(name, uuid);
										BluetoothSocket socket = btserver.accept();
										progressDialog.dismiss();
										Intent intent = new Intent(MainMenu.this, GobangGameWangluo.class);
										startActivity(intent);
										BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
										writerServer = new PrintStream(socket.getOutputStream(), true);
										while (true) {
											String line = reader.readLine();
											String[] temp = line.split(" ");
											if (temp.length == 1) {
												switch (Integer.parseInt(temp[0])) {
												case 1:// ����
													GameScreenWangluo.initNet();
													break;
												case 9:// �����Ѿ�����ȷ����ť
													isFinish = true;
													GameScreenWangluo.chessFlag = true;
													break;
												}
											} else {
												int col = Integer.parseInt(temp[0]);
												int row = Integer.parseInt(temp[1]);
												Chess.chesses[col][row] = Chess.WHITE;
												if (Chess.check(col, row, Chess.WHITE)) {// ����ʤ
													handler.sendEmptyMessage(GobangGameWangluo.MSG_WHITE_WIN);
												}
												GameScreenWangluo.player2.run(null, new Point(col, row));
												GameScreenWangluo.allFreePoints.add(new Point(col, row));
												GameScreenWangluo.chessFlag = true;
											}
										}

									} catch (IOException e) {
									}

								}
							};
							threadServer.start();
						}
						// �� ��
						if (item == 1) {
							isServer = false;
							AlertDialog.Builder builder = new AlertDialog.Builder((Context) MainMenu.this);
							final EditText editText = new EditText((Context) MainMenu.this);
							editText.setHint("01:23:77:35:2F:AA");
							builder.setTitle("����������MAC��ַ").setView(editText).setPositiveButton("ȷ��", new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog, int which) {
									String temp = editText.getText().toString().trim();
									ipString = temp;
									if (temp.equals("")) {
										ipString = "ac:f7:f3:cb:39:c6";
									}
									System.out.println("lanya4");
									final ProgressDialog progressDialog = new ProgressDialog(MainMenu.this);
									progressDialog.setTitle("��������...");
									progressDialog.setCancelable(false);
									progressDialog.show();
									System.out.println("lanya5");
									// �ͻ���
									threadClient = new Thread() {
										public void run() {
											try {
												System.out.println("lanya6");
												Set<BluetoothDevice> devices = bluetooth.getBondedDevices();
												BluetoothDevice device = null;
												if (devices != null && devices.size() > 0) {
													Iterator<BluetoothDevice> iterator = devices.iterator();
													while (iterator.hasNext()) {
														BluetoothDevice dev = iterator.next();
														if (dev.getName().contains("wang")) {
															device = dev;
															break;
														}
													}
													if (device == null) {
														// ����ȡ��һ��
														device = devices.iterator().next();
													}
												}

												System.out.println("lanya1");
												BluetoothSocket socket = device.createInsecureRfcommSocketToServiceRecord(uuid);
												System.out.println("lanya2");
												socket.connect();
												System.out.println("lanya3");
												progressDialog.dismiss();
												Intent intent = new Intent(MainMenu.this, GobangGameWangluo.class);
												startActivity(intent);
												GameScreenWangluo.chessFlag = false;
												OutputStream out = socket.getOutputStream();
												BufferedReader reader1 = new BufferedReader(new InputStreamReader(socket.getInputStream()));
												writerClient = new PrintWriter(out, true);
												while (true) {
													String line = reader1.readLine();
													String[] temp = line.split(" ");
													if (temp.length == 1) {
														switch (Integer.parseInt(temp[0])) {
														case 1:// ����
															GameScreenWangluo.initNet();
															break;
														case 9:// �����Ѿ�����ȷ����ť
															isFinish = true;
															GameScreenWangluo.chessFlag = true;
															break;
														}
													} else {
														int col = Integer.parseInt(temp[0]);
														int row = Integer.parseInt(temp[1]);
														Chess.chesses[col][row] = Chess.WHITE;
														if (Chess.check(col, row, Chess.WHITE)) {// ����ʤ
															handler.sendEmptyMessage(GobangGameWangluo.MSG_WHITE_WIN);
														}
														GameScreenWangluo.player2.run(null, new Point(col, row));
														GameScreenWangluo.allFreePoints.add(new Point(col, row));
														GameScreenWangluo.chessFlag = true;
													}
												}
											} catch (IOException e) {
												e.printStackTrace();
											}
										}
									};
									threadClient.start();
								}

							});
							builder.setNegativeButton("ȡ��", null);
							builder.create().show();
						}
					}
				});
				builder.setNegativeButton("ȡ��", null);
				builder.create().show();
			}
		});
	}
}
