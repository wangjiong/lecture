package com.badlogic.androidgames.gobang;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.TextView;

public class Guanyu extends Activity{
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.guanyu);
		TextView back=(TextView) findViewById(R.id.guanyu_back);
		back.setOnClickListener(new OnClickListener(){
			public void onClick(View v) {
				Guanyu.this.finish();
			}
		});
	}
}
