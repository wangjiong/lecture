package com.badlogic.androidgames.gobang;

import com.badlogic.androidgames.framework.Music;
import com.badlogic.androidgames.framework.gl.Texture;
import com.badlogic.androidgames.framework.gl.TextureRegion;
import com.badlogic.androidgames.framework.impl.GLGame;

public class Assets {
	public static Texture items;
	public static TextureRegion boardRegion;
	public static TextureRegion blackRegion;
	public static TextureRegion whiteRegion;
	public static Music music;

	public static void load(GLGame game) {
		items = new Texture(game, "atlas.png");
		boardRegion = new TextureRegion(items, 2, 2, 320, 480);
		blackRegion = new TextureRegion(items, 362, 2, 36, 36);
		whiteRegion = new TextureRegion(items, 324, 2, 36, 36);

		music = game.getAudio().newMusic("bg.mp3");
		music.setLooping(true);
		music.setVolume(0.5f);
		if (Settings.soundEnabled) {
			music.play();
		}
	}

	public static void reload() {
		items.reload();
		if (Settings.soundEnabled) {
			music.play();
		}
	}
}
