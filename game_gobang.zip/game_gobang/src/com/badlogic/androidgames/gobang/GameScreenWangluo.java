package com.badlogic.androidgames.gobang;

import java.util.ArrayList;
import java.util.List;

import javax.microedition.khronos.opengles.GL10;

import com.badlogic.androidgames.framework.Game;
import com.badlogic.androidgames.framework.Input.TouchEvent;
import com.badlogic.androidgames.framework.gl.Camera2D;
import com.badlogic.androidgames.framework.gl.SpriteBatcher;
import com.badlogic.androidgames.framework.impl.GLScreen;
import com.badlogic.androidgames.framework.math.OverlapTester;
import com.badlogic.androidgames.framework.math.Rectangle;
import com.badlogic.androidgames.framework.math.Vector2;
import com.badlogic.androidgames.gobang.ai.HumanPlayer;
import com.badlogic.androidgames.gobang.ai.IPlayer;
import com.badlogic.androidgames.gobang.ai.Point;

public class GameScreenWangluo extends GLScreen {
	Camera2D guiCam;
	SpriteBatcher batcher;
	Vector2 touchPoint;
	Rectangle replayBounds;
	Rectangle optionBounds;
	Rectangle quitBounds;
	// ���ӱ�־
	public static boolean chessFlag = true;
	// �����ƶ�
	boolean movetouchFlag = true, multouchFlag = true;
	Vector2 cameraPos = new Vector2(), mPos = new Vector2(),
			curPos = new Vector2();
	// ��㻬��
	Vector2[] mPoints = new Vector2[] { new Vector2(), new Vector2() },
			curPoints = new Vector2[] { new Vector2(), new Vector2() };
	// ˫���¼�
	private int count = 0;
	private long firstClick = 0;
	private long lastClick = 0;
	boolean scaleFlag = false;
	// �˻�
	public static IPlayer player1;
	public static IPlayer player2;
	public static List<Point> allFreePoints;

	public static void initNet() {
		player1 = new HumanPlayer();
		player2 = new HumanPlayer();
		allFreePoints = new ArrayList<Point>();
		for (int i = 0; i < Board.SIZE_WIDTH; i++) {
			for (int j = 0; j < Board.SIZE_HEIGHT; j++) {
				allFreePoints.add(new Point(i, j));
			}
		}
		player1.setChessboard(Board.SIZE_WIDTH, Board.SIZE_HEIGHT,
				allFreePoints);
		player2.setChessboard(Board.SIZE_WIDTH, Board.SIZE_HEIGHT,
				allFreePoints);
		Chess.clear();
	}

	public static void backNet() {
		if (player1.getMyPoints().size() != 0
				&& player2.getMyPoints().size() != 0) {
			Point point1 = GameScreenWangluo.player1.getMyPoints().get(
					GameScreenWangluo.player1.getMyPoints().size() - 1);
			Point point2 = GameScreenWangluo.player2.getMyPoints().get(
					GameScreenWangluo.player2.getMyPoints().size() - 1);
			GameScreenWangluo.allFreePoints.add(point1);
			GameScreenWangluo.allFreePoints.add(point2);
			Chess.chesses[point1.x][point1.y] = Chess.NULL;
			Chess.chesses[point2.x][point2.y] = Chess.NULL;
			GameScreenWangluo.player1.getMyPoints().remove(point1);
			GameScreenWangluo.player2.getMyPoints().remove(point2);
		}
	}

	public GameScreenWangluo(Game game) {
		super(game);
		guiCam = new Camera2D(glGraphics, Constant.WIDTH, Constant.HEIGHT);
		batcher = new SpriteBatcher(glGraphics, 200);
		touchPoint = new Vector2();
		replayBounds = new Rectangle(17, 480 - 48, 94, 39);
		optionBounds = new Rectangle(115, 480 - 48, 94, 39);
		quitBounds = new Rectangle(210, 480 - 48, 94, 39);
		// �˻�
		initNet();
		MainMenu.handler = ((GobangGameWangluo) game).handler;
	}

	@Override
	public void update(float deltaTime) {
		List<TouchEvent> touchEvents = game.getInput().getTouchEvents();
		int len = touchEvents.size();
		for (int i = 0; i < len; i++) {
			TouchEvent event = touchEvents.get(i);
			// �����ƶ�
			if (event.type == TouchEvent.TOUCH_DOWN) {
				movetouchFlag = false;
				multouchFlag = false;
				// ��㴥������
				if (game.getInput().isTouchDown(0)
						&& game.getInput().isTouchDown(1)) {
					multouchFlag = true;
					for (int j = 0; j < 2; j++) {
						mPoints[j].set(game.getInput().getTouchX(j), game
								.getInput().getTouchY(j));
					}
				}
				// ���㻬��
				mPos.set(event.x, event.y);
				cameraPos.set(guiCam.position);
				// ˫���¼�
				if (multouchFlag == false) {
					// ����ڶ��ε�� �����һ�ε��ʱ����� ��ô���ڶ��ε����Ϊ��һ�ε��
					if (firstClick != 0
							&& System.currentTimeMillis() - firstClick > 300) {
						count = 0;
					}
					count++;
					if (count == 1) {
						firstClick = System.currentTimeMillis();
					} else if (count == 2) {
						lastClick = System.currentTimeMillis();
						if (lastClick - firstClick < 500) {
							if (scaleFlag == false) {
								guiCam.zoom = 0.5f;
								touchPoint.set(event.x, event.y);
								guiCam.touchToWorld(touchPoint);
								guiCam.position.x += (touchPoint.x - guiCam.position.x)
										* guiCam.zoom * 2;
								guiCam.position.y += (touchPoint.y - guiCam.position.y)
										* guiCam.zoom * 2;
								scaleFlag = true;
							} else {
								guiCam.zoom = 1f;
								guiCam.position.set(Constant.WIDTH / 2,
										Constant.HEIGHT / 2);
								scaleFlag = false;
							}
						}
						count = 0;
						firstClick = 0;
						lastClick = 0;
					}
				}
			}
			if (event.type == TouchEvent.TOUCH_DRAGGED) {
				// ��㴥���ƶ�
				if (game.getInput().isTouchDown(0)
						&& game.getInput().isTouchDown(1)) {
					movetouchFlag = true;
					for (int j = 0; j < 2; j++) {
						if (mPoints[j].x == 0 && mPoints[j].y == 0) {
							mPoints[j].set(game.getInput().getTouchX(j), game
									.getInput().getTouchY(j));
						}
					}
					for (int j = 0; j < 2; j++) {
						curPoints[j].set(game.getInput().getTouchX(j), game
								.getInput().getTouchY(j));
					}
					float scale = mPoints[0].distSquared(mPoints[1])
							/ curPoints[0].distSquared(curPoints[1]);
					if (scale < 1) {
						if (guiCam.zoom >= 0.5f) {
							guiCam.zoom -= scale * 0.05f;
						}
					} else if (scale > 1) {
						if (guiCam.zoom < 1) {
							guiCam.zoom += scale * 0.05f;
						} else {
							guiCam.position.set(Constant.WIDTH / 2,
									Constant.HEIGHT / 2);
						}
					}
					for (int j = 0; j < 2; j++) {
						mPoints[j].set(game.getInput().getTouchX(j), game
								.getInput().getTouchY(j));
					}
				}
				// ���㻬��
				if (multouchFlag == false) {
					curPos.set(event.x, event.y);
					float tempx = curPos.x - mPos.x;
					float tempy = curPos.y - mPos.y;
					if (Math.abs(tempx) > 5 || Math.abs(tempy) > 5) {
						movetouchFlag = true;
						if (Math.abs(guiCam.zoom - 1) < 0.05f
								&& Math.abs(guiCam.position.x - 160) < 5
								&& Math.abs(guiCam.position.y - 240) < 5)
							;
						else {
							if (tempx > 0
									&& guiCam.position.x < 160 * guiCam.zoom
									|| tempx < 0
									&& guiCam.position.x > 320 - 160 * guiCam.zoom) {
								if (tempy > 0
										&& guiCam.position.y > 480 - 240 * guiCam.zoom
										|| tempy < 0
										&& guiCam.position.y < 240 * guiCam.zoom)
									;
								else {
									guiCam.position.y += tempy * 0.3f;
								}
							} else {
								guiCam.position.x -= tempx * 0.3f;
								if (tempy > 0
										&& guiCam.position.y > 480 - 240 * guiCam.zoom
										|| tempy < 0
										&& guiCam.position.y < 240 * guiCam.zoom)
									;
								else {
									guiCam.position.y += tempy * 0.3f;
								}
							}
						}
						mPos.set(event.x, event.y);
					}
				}
			}
			if (event.type == TouchEvent.TOUCH_UP) {
				// ��Ϊ�ƶ��¼����㴥���¼��򲻴��������¼�
				if (movetouchFlag == true || multouchFlag == true) {
					return;
				}
				touchPoint.set(event.x, event.y);
				guiCam.touchToWorld(touchPoint);
				// 3���˵��¼�
				if (OverlapTester.pointInRectangle(replayBounds, touchPoint)) {
					((GobangGameWangluo) game).handler
							.sendEmptyMessage(GobangGameWangluo.MSG_REPLAY);
					return;
				}
				if (OverlapTester.pointInRectangle(optionBounds, touchPoint)) {
					((GobangGameWangluo) game).handler
							.sendEmptyMessage(GobangGameWangluo.MSG_OPTION);
					return;
				}
				if (OverlapTester.pointInRectangle(quitBounds, touchPoint)) {
					((GobangGameWangluo) game).handler
							.sendEmptyMessage(GobangGameWangluo.MSG_EXIT);
					return;
				}
				// �����¼�
				if (touchPoint.x < 346 && touchPoint.y < 346) {
					int col = (int) touchPoint.x / 36;
					int row = (int) touchPoint.y / 36;
					if ((touchPoint.x + 4) / 36 < (col + 1)
							&& (touchPoint.y + 4) / 36 < (row + 1)) {
						if (col < 9 && row < 9
								&& Chess.chesses[col][row] == Chess.NULL) {
							if (chessFlag) {
								chessFlag = false;
								player1.run(player2.getMyPoints(), new Point(
										col, row));
								Chess.chesses[col][row] = Chess.BLACK;
								// ͨ��
								if (MainMenu.isServer == true) {
									MainMenu.writerServer.println(col + " "
											+ row);
								} else {
									MainMenu.writerClient.println(col + " "
											+ row);
								}
								if (Chess.check(col, row, Chess.BLACK)) {// ����ʤ
									((GobangGameWangluo) game).handler
											.sendEmptyMessage(GobangGameWangluo.MSG_BLACK_WIN);
									return;
								}
								if (allFreePoints.isEmpty()) {// ƽ��
									((GobangGameWangluo) game).handler
											.sendEmptyMessage(GobangGameWangluo.MSG_DRAW);
									return;
								}
							}
						}
					}
				}
			}
		}
	}

	@Override
	public void present(float deltaTime) {
		GL10 gl = glGraphics.getGL();
		gl.glClear(GL10.GL_COLOR_BUFFER_BIT);
		guiCam.setViewportAndMatrices();
		gl.glEnable(GL10.GL_TEXTURE_2D);
		gl.glEnable(GL10.GL_BLEND);
		gl.glBlendFunc(GL10.GL_SRC_ALPHA, GL10.GL_ONE_MINUS_SRC_ALPHA);
		// ���Ʊ���
		batcher.beginBatch(Assets.items);
		batcher.drawSprite(160, 240, 320, 480, Assets.boardRegion);
		// ��������
		for (int i = 0; i < 9; i++)
			for (int j = 0; j < 9; j++) {
				switch (Chess.chesses[i][j]) {
				case Chess.NULL:
					break;
				case Chess.BLACK:
					batcher.drawSprite(16 + i * 36, 16 + j * 36, 36, 36,
							Assets.blackRegion);
					break;
				case Chess.WHITE:
					batcher.drawSprite(16 + i * 36, 16 + j * 36, 36, 36,
							Assets.whiteRegion);
					break;
				}
			}
		batcher.endBatch();
		gl.glDisable(GL10.GL_BLEND);
		gl.glDisable(GL10.GL_TEXTURE_2D);
	}

	@Override
	public void pause() {
	}

	@Override
	public void resume() {
	}

	@Override
	public void dispose() {
	}

}
