package com.badlogic.androidgames.framework.gl;

import com.badlogic.androidgames.framework.gl.Texture;

public class AnimationTexture {
	public static final int ANIMATION_LOOPING = 0;
	public static final int ANIMATION_NONLOOPING = 1;
	Texture[] keyTextures;
	final float frameDuration;

	public AnimationTexture(float frameDuration, Texture... keyTextures) {
		this.frameDuration = frameDuration;
		this.keyTextures = keyTextures;
	}

	public Texture getKeyFrame(float startTime, int mode) {
		int frameNumber = (int) (startTime / frameDuration);
		if (mode == ANIMATION_NONLOOPING) {
			frameNumber = Math.min(keyTextures.length - 1, frameNumber);
		} else {
			frameNumber = frameNumber % keyTextures.length;
		}
		return keyTextures[frameNumber];
	}
}
